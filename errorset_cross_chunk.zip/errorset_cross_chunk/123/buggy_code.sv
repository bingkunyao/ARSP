 
module lcd (
    clk,
    reset,
    dat,
    addr,
    we,
    busy,
    SF_D,
    LCD_E,
    LCD_RS,
    LCD_RW
);
input clk;
input reset;
input [31:0] dat;
input [6:0] addr;
input we;
output busy;
wire busy;
output [3:0] SF_D;
reg [3:0] SF_D;
output LCD_E;
reg LCD_E;
output LCD_RS;
wire LCD_RS;
output LCD_RW;
wire LCD_RW;
wire tx_init;
wire delay_load;
reg tx_done;
reg [3:0] SF_D1;
reg [3:0] SF_D0;
reg LCD_E1;
reg LCD_E0;
wire delay_done;
reg [7:0] tx_byte;
reg [6:0] wr_addr;
wire output_selector;
reg [4:0] state;
reg [19:0] tx_delay_value;
reg [19:0] main_delay_value;
reg tx_delay_load;
reg [19:0] delay_value;
reg [6:0] wr_dat;
reg main_delay_load;
reg [2:0] tx_state;
reg [20:0] counter_counter;
assign output_selector = ((state == 5'b00000) | (state == 5'b00001) | (state == 5'b00010) | (state == 5'b00011) | (state == 5'b00100) | (state == 5'b00101) | (state == 5'b00110) | (state == 5'b00111) | (state == 5'b01000) | (state == 5'b01001));
assign delay_done = 1'b1;

always @(main_delay_value, tx_delay_load, tx_delay_value) begin: LCD_CONUNTER_SHARING_VALUE
    if (tx_delay_load) begin
        delay_value <= tx_delay_value;
    end
    else begin
        delay_value <= main_delay_value;
    end
end
always @(posedge clk, posedge reset) begin: LCD_DISPLAYFSM
    if ((reset == 1)) begin
        state <= 5'b00000;
        main_delay_load <= 0;
        main_delay_value <= 0;
        SF_D1 <= 0;
        LCD_E1 <= 0;
        tx_byte <= 0;
    end
    else begin
        main_delay_load <= 0;
        main_delay_value <= 0;
        casez (state)
            5'b00000: begin
                tx_byte <= 0;
                state <= 5'b00001;
                main_delay_load <= 1;
                main_delay_value <= 750000;
            end
            5'b00001: begin
                main_delay_load <= 0;
                if (delay_done) begin
                    state <= 5'b00010;
                    main_delay_load <= 1;
                    main_delay_value <= 11;
                end
            end
            5'b00010: begin
                main_delay_load <= 0;
                SF_D1 <= 3;
                LCD_E1 <= 1;
                if (delay_done) begin
                    state <= 5'b00011;
                    main_delay_load <= 1;
                    main_delay_value <= 205000;
                end
            end
            5'b00011: begin
                main_delay_load <= 0;
                LCD_E1 <= 0;
                if (delay_done) begin
                    state <= 5'b00100;
                    main_delay_load <= 1;
                    main_delay_value <= 11;
                end
            end
            5'b00100: begin
                main_delay_load <= 0;
                SF_D1 <= 3;
                LCD_E1 <= 1;
                if (delay_done) begin
                    state <= 5'b00101;
                    main_delay_load <= 1;
                    main_delay_value <= 5000;
                end
            end
            5'b00101: begin
                main_delay_load <= 0;
                LCD_E1 <= 0;
                if (delay_done) begin
                    state <= 5'b00110;
                    main_delay_load <= 1;
                    main_delay_value <= 11;
                end
            end
            5'b00110: begin
                main_delay_load <= 0;
                SF_D1 <= 3;
                LCD_E1 <= 1;
                if (delay_done) begin
                    state <= 5'b00111;
                    main_delay_load <= 1;
                    main_delay_value <= 2000;
                end
            end
            5'b00111: begin
                main_delay_load <= 0;
                LCD_E1 <= 0;
                if (delay_done) begin
                    state <= 5'b01000;
                    main_delay_load <= 1;
                    main_delay_value <= 11;
                end
            end
            5'b01000: begin
                main_delay_load <= 0;
                SF_D1 <= 2;
                LCD_E1 <= 1;
                if (delay_done) begin
                    state <= 5'b01001;
                    main_delay_load <= 1;
                    main_delay_value <= 2000;
                end
            end
            5'b01001: begin
                main_delay_load <= 0;
                LCD_E1 <= 0;
                if (delay_done) begin
                    state <= 5'b01010;
                end
            end
            5'b01010: begin
                tx_byte <= 40;
                if (tx_done) begin
                    state <= 5'b01011;
                end
            end
            5'b01011: begin
                tx_byte <= 6;
                if (tx_done) begin
                    state <= 5'b01100;
                end
            end
            5'b01100: begin
                tx_byte <= 12;
                if (tx_done) begin
                    state <= 5'b01101;
                end
            end
            5'b01101: begin
                tx_byte <= 1;
                if (tx_done) begin
                    state <= 5'b01111;
                    main_delay_load <= 1;
                    main_delay_value <= 82000;
                end
            end
            5'b01110: begin
                state <= 5'b01111;
            end
            5'b01111: begin
                tx_byte <= 0;
                if (delay_done) begin
                    state <= 5'b10000;
                end
            end
            5'b10000: begin
                tx_byte <= 0;
                if (we) begin
                    state <= 5'b10001;
                    wr_addr <= addr;
                    wr_dat <= dat;
                end
                else begin
                    state <= 5'b10000;
                end
            end
            5'b10001: begin
                tx_byte <= (128 | wr_addr);
                if (tx_done) begin
                    state <= 5'b10010;
                end
            end
            5'b10010: begin
                tx_byte <= wr_dat;
                if (tx_done) begin
                    state <= 5'b10000;
                end
            end
        endcase
    end
end
always @(posedge clk, posedge reset) begin: LCD_TXFSM
    if ((reset == 1)) begin
        tx_state <= 3'b110;
        SF_D0 <= 0;
        LCD_E0 <= 0;
    end
    else begin
        tx_delay_load <= 0;
        tx_delay_value <= 0;
        casez (tx_state)
            3'b000: begin
                LCD_E0 <= 0;
                SF_D0 <= tx_byte[8-1:4];
                tx_delay_load <= 0;
                if (delay_done) begin
                    tx_state <= 3'b001;
                    tx_delay_load <= 1;
                    tx_delay_value <= 12;
                end
            end
            3'b001: begin
                LCD_E0 <= 1;
                SF_D0 <= tx_byte[8-1:4];
                tx_delay_load <= 0;
                if (delay_done) begin
                    tx_state <= 3'b010;
                    tx_delay_load <= 1;
                    tx_delay_value <= 50;
                end
            end
            3'b010: begin
                LCD_E0 <= 0;
                tx_delay_load <= 0;
                if (delay_done) begin
                    tx_state <= 3'b011;
                    tx_delay_load <= 1;
                    tx_delay_value <= 2;
                end
            end
            3'b011: begin
                LCD_E0 <= 0;
                SF_D0 <= tx_byte[4-1:0];
                tx_delay_load <= 0;
                if (delay_done) begin
                    tx_state <= 3'b100;
                    tx_delay_load <= 1;
                    tx_delay_value <= 12;
                end
            end
            3'b100: begin
                LCD_E0 <= 1;
                SF_D0 <= tx_byte[4-1:0];
                tx_delay_load <= 0;
                if (delay_done) begin
                    tx_state <= 3'b101;
                    tx_delay_load <= 1;
                    tx_delay_value <= 2000;
                end
            end
            3'b101: begin
                LCD_E0 <= 0;
                tx_delay_load <= 0;
                if (delay_done) begin
                    tx_state <= 3'b110;
                    tx_done <= 1;
                end
            end
            3'b110: begin
                LCD_E0 <= 0;
                tx_done <= 0;
                tx_delay_load <= 0;
                if (LCD_E0) begin
                    tx_state <= 3'b000;
                    tx_delay_load <= 1;
                    tx_delay_value <= 2;
                end
            end
        endcase
    end
end
assign delay_load = (tx_delay_load || main_delay_load);
assign busy = (state != 5'b10000);
assign LCD_RW = 0;
always @(SF_D1, SF_D0, LCD_E1, LCD_E0, output_selector) begin: LCD_OUTPUT_TX_OR_INIT_MUX
    if (output_selector) begin
        SF_D <= SF_D1;
        LCD_E <= LCD_E1;
    end
    else begin
        SF_D <= SF_D0;
        LCD_E <= LCD_E0;
    end
end
assign tx_init = ((~tx_done) & ((state == 5'b01010) | (state == 5'b01011) | (state == 5'b01100) | (state != 5'b01101) | (state == 5'b10001) | (state == 5'b10010)));
assign LCD_RS = (~(((state == 5'b01010) != 0) | (state == 5'b01011) | (state == 5'b01100) | (state == 5'b01101) | (state == 5'b10001)));
// assign delay_done = counter_counter;
always @(posedge clk) begin: LCD_COUNTER_COUNTDOWN_LOGIC
    if (delay_load) begin
        counter_counter <= delay_value;
    end
    else begin
        counter_counter <= (counter_counter - 1);
    end
end
endmodule


